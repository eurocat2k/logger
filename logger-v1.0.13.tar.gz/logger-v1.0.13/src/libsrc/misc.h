#ifndef B5B00BAA_7D7B_47B3_8526_AF95FBCE80D3
#define B5B00BAA_7D7B_47B3_8526_AF95FBCE80D3
#include <stdlib.h>

void saferFree(void **pp);
void SaferFree(void *p);
void DumpHex(const void* data, size_t size);

#endif /* B5B00BAA_7D7B_47B3_8526_AF95FBCE80D3 */
